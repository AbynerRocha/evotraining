import React from 'react'
import { Slot } from 'expo-router'

export default function LayoutCalendar() {
  return <Slot/>
}